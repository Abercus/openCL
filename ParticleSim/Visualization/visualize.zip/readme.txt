Usage:
1. Run the simulation program with "-o <filename>" option.
2. Drag-and-drop the produced data file onto the visualize.exe or type 
   "visualize.exe <filename>" from the command line.
